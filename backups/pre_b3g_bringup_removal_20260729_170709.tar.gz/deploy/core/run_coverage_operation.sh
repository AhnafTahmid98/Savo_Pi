#!/usr/bin/env bash
set -euo pipefail

SAVO_ROOT="${SAVO_ROOT:-/home/ahnaf-tahmid/Savo_Pi}"
SAVO_WS="${SAVO_WS:-${SAVO_ROOT}/savo_ws}"
ROS_DISTRO="${ROS_DISTRO:-jazzy}"

: "${SAVO_MAP_YAML:?SAVO_MAP_YAML must point to a released saved-map YAML file}"

SAVO_MAP_ID="${SAVO_MAP_ID:-active_map}"
SAVO_USE_SIM_TIME="${SAVO_USE_SIM_TIME:-false}"
SAVO_NAV_AUTOSTART="${SAVO_NAV_AUTOSTART:-false}"
SAVO_USE_REAL_ROBOT_PROFILE="${SAVO_USE_REAL_ROBOT_PROFILE:-true}"

if [[ ! -f "${SAVO_MAP_YAML}" ]]; then
  echo "Coverage operation map does not exist: ${SAVO_MAP_YAML}" >&2
  exit 2
fi

source "/opt/ros/${ROS_DISTRO}/setup.bash"
source "${SAVO_WS}/install/setup.bash"

exec ros2 launch savo_bringup coverage_operation.launch.py \
  map:="${SAVO_MAP_YAML}" \
  map_id:="${SAVO_MAP_ID}" \
  use_sim_time:="${SAVO_USE_SIM_TIME}" \
  autostart:="${SAVO_NAV_AUTOSTART}" \
  use_real_robot_profile:="${SAVO_USE_REAL_ROBOT_PROFILE}"
