from glob import glob
from setuptools import find_packages
from setuptools import setup


package_name = 'savo_bringup'

setup(
    name=package_name,
    version='0.2.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        (
            'share/ament_index/resource_index/packages',
            ['resource/' + package_name],
        ),
        ('share/' + package_name, ['package.xml', 'README.md']),
        ('share/' + package_name + '/launch', glob('launch/*')),
        ('share/' + package_name + '/config', glob('config/*')),
        ('share/' + package_name + '/params', glob('params/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Ahnaf Tahmid',
    maintainer_email='tahmidahnaf998@gmail.com',
    description=(
        'Production launch and deployment ownership for Robot Savo core '
        'operations.'
    ),
    license='Proprietary',
    tests_require=['pytest'],
)
