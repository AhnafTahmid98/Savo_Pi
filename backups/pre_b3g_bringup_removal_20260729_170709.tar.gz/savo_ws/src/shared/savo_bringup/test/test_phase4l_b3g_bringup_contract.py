"""Phase 4L-B3G bringup and deployment ownership contracts."""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LAUNCH = ROOT / 'launch/coverage_operation.launch.py'
PACKAGE = ROOT / 'package.xml'
SETUP = ROOT / 'setup.py'
REPOSITORY = ROOT.parents[3]
DEPLOY_SCRIPT = REPOSITORY / 'deploy/core/run_coverage_operation.sh'
DEPLOY_ENV = REPOSITORY / 'deploy/core/coverage_operation.env.example'
SYSTEMD_UNIT = (
    REPOSITORY / 'deploy/systemd/savo_coverage_operation.service'
)


def test_coverage_operation_launch_is_implemented():
    """The B3G bringup launch must not remain a scaffold."""
    text = LAUNCH.read_text(encoding='utf-8')
    assert 'savo_supervisor' in text
    assert 'saved_map_navigation.launch.py' in text
    assert 'coverage_mapping.launch.xml' in text
    assert 'coverage_execution_handoff.launch.xml' in text
    assert 'coverage_operation_orchestrator.launch.xml' in text


def test_b3f_services_are_hidden_by_unified_bringup():
    """Only the B3G public approval endpoint is externally exposed."""
    text = LAUNCH.read_text(encoding='utf-8')
    assert '/savo_mapping/_internal/' in text
    assert 'coverage_execution/approve' in text
    assert "'start_execution_handoff': 'false'" in text


def test_nav2_autostart_remains_opt_in():
    """Unified bringup must not activate Nav2 implicitly."""
    text = LAUNCH.read_text(encoding='utf-8')
    assert "'autostart'" in text
    assert "default_value='false'" in text


def test_bringup_is_a_real_ament_python_package():
    """Launch assets must be installed by the package."""
    package = PACKAGE.read_text(encoding='utf-8')
    setup = SETUP.read_text(encoding='utf-8')
    assert '<build_type>ament_python</build_type>' in package
    assert "glob('launch/*')" in setup
    assert 'resource/' in setup


def test_deployment_assets_are_explicit_and_safe():
    """Deployment requires a released map and keeps autostart false."""
    script = DEPLOY_SCRIPT.read_text(encoding='utf-8')
    environment = DEPLOY_ENV.read_text(encoding='utf-8')
    unit = SYSTEMD_UNIT.read_text(encoding='utf-8')
    assert 'SAVO_MAP_YAML' in script
    assert 'SAVO_NAV_AUTOSTART' in script
    assert 'SAVO_NAV_AUTOSTART=false' in environment
    assert 'ConditionPathExists' in unit
    assert 'EnvironmentFile' in unit
