# savo_bringup

`savo_bringup` owns production assembly of Robot Savo launch graphs. Phase
4L-B3G adds `coverage_operation.launch.py`, which connects the monitor-only
supervisor, saved-map Nav2 stack, Coverage planner, private B3F handoff and the
public B3G operation orchestrator.

Nav2 lifecycle `autostart` remains `false` by default. Installing or launching
this package does not itself authorize movement. Coverage execution still
requires the public operator approval service and a fresh authorized supervisor
state before the private B3F approval service can be called.
