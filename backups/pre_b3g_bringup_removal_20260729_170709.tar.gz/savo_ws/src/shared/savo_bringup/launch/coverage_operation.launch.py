# Copyright 2026 Ahnaf Tahmid
# SPDX-License-Identifier: LicenseRef-Proprietary

"""Launch the guarded Robot Savo Coverage operation chain."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.actions import IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.launch_description_sources import AnyLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    """Create the unified Coverage operation launch description."""
    map_yaml = LaunchConfiguration('map')
    map_id = LaunchConfiguration('map_id')
    use_sim_time = LaunchConfiguration('use_sim_time')
    autostart = LaunchConfiguration('autostart')
    start_supervisor = LaunchConfiguration('start_supervisor')
    start_navigation = LaunchConfiguration('start_navigation')
    start_coverage_mapper = LaunchConfiguration('start_coverage_mapper')
    use_real_robot_profile = LaunchConfiguration(
        'use_real_robot_profile'
    )

    supervisor_launch = PathJoinSubstitution(
        [
            FindPackageShare('savo_supervisor'),
            'launch',
            'supervisor.launch.py',
        ]
    )
    navigation_launch = PathJoinSubstitution(
        [
            FindPackageShare('savo_nav'),
            'launch',
            'saved_map_navigation.launch.py',
        ]
    )
    coverage_mapping_launch = PathJoinSubstitution(
        [
            FindPackageShare('savo_mapping'),
            'launch',
            'coverage_mapping.launch.xml',
        ]
    )
    handoff_launch = PathJoinSubstitution(
        [
            FindPackageShare('savo_mapping'),
            'launch',
            'coverage_execution_handoff.launch.xml',
        ]
    )
    orchestrator_launch = PathJoinSubstitution(
        [
            FindPackageShare('savo_mapping'),
            'launch',
            'coverage_operation_orchestrator.launch.xml',
        ]
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                'map',
                default_value='',
                description='Absolute saved-map YAML path.',
            ),
            DeclareLaunchArgument(
                'map_id',
                default_value='saved_map',
                description='Released map identity.',
            ),
            DeclareLaunchArgument(
                'use_sim_time',
                default_value='false',
                description='Use the ROS simulation clock.',
            ),
            DeclareLaunchArgument(
                'autostart',
                default_value='false',
                description=(
                    'Nav2 lifecycle autostart. Production default remains '
                    'false until explicit activation.'
                ),
            ),
            DeclareLaunchArgument(
                'start_supervisor',
                default_value='true',
                description='Start the monitor-only supervisor.',
            ),
            DeclareLaunchArgument(
                'start_navigation',
                default_value='true',
                description='Start saved-map Nav2 and guarded gateways.',
            ),
            DeclareLaunchArgument(
                'start_coverage_mapper',
                default_value='true',
                description='Start the Coverage planner.',
            ),
            DeclareLaunchArgument(
                'use_real_robot_profile',
                default_value='false',
                description='Load conservative real-robot planning values.',
            ),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(supervisor_launch),
                condition=IfCondition(start_supervisor),
            ),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(navigation_launch),
                condition=IfCondition(start_navigation),
                launch_arguments={
                    'map': map_yaml,
                    'map_id': map_id,
                    'use_sim_time': use_sim_time,
                    'autostart': autostart,
                }.items(),
            ),
            IncludeLaunchDescription(
                AnyLaunchDescriptionSource(coverage_mapping_launch),
                condition=IfCondition(start_coverage_mapper),
                launch_arguments={
                    'start_execution_handoff': 'false',
                    'use_real_robot_profile': use_real_robot_profile,
                    'use_sim_time': use_sim_time,
                }.items(),
            ),
            IncludeLaunchDescription(
                AnyLaunchDescriptionSource(handoff_launch),
                launch_arguments={
                    'approve_service': (
                        '/savo_mapping/_internal/'
                        'coverage_execution/approve'
                    ),
                    'cancel_service': (
                        '/savo_mapping/_internal/'
                        'coverage_execution/cancel'
                    ),
                    'reset_service': (
                        '/savo_mapping/_internal/'
                        'coverage_execution/reset'
                    ),
                    'use_sim_time': use_sim_time,
                }.items(),
            ),
            IncludeLaunchDescription(
                AnyLaunchDescriptionSource(orchestrator_launch),
                launch_arguments={
                    'enabled': 'true',
                    'use_sim_time': use_sim_time,
                }.items(),
            ),
        ]
    )
