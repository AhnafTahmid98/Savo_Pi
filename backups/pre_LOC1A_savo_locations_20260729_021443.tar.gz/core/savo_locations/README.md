# Robot Savo — `savo_locations`

`savo_locations` is the authoritative semantic-location registry for
Robot Savo.

## Ownership

This package owns:

- canonical location IDs;
- human-readable display names;
- deterministic aliases;
- semantic location types;
- active-map and map-revision binding;
- released-map provenance;
- safe navigation approach poses;
- optional confirmation poses;
- expected AprilTag family and ID;
- candidate and approved-location lifecycle;
- location enable/disable state;
- registry persistence and audit history.

This package does not own:

- AprilTag image detection;
- camera-to-map transformations;
- occupancy-grid validation;
- path planning;
- motor commands;
- natural-language intent classification;
- final robot-wide safety authorization.

## Package relationships

- `savo_head` visually detects and confirms AprilTags.
- `savo_mapping` georeferences observations and proposes candidates.
- `savo_locations` stores and resolves approved locations.
- `savo_nav` consumes a resolved approach pose and confirms arrival.
- SavoMind or `savo_bridge` resolves natural-language destination intent.
- `savo_supervisor` observes readiness and safety state.

## Locked LOC-0 terminology

Map context uses:

- `map_id`
- `map_revision`
- `map_release_id`

`map_revision` is the active numeric map revision used by runtime
contracts.

`map_release_id` records released-map provenance and is not a substitute
for `map_revision`.

## Pose separation

The AprilTag pose is not automatically a safe navigation goal.

A location may contain:

- `tag_pose_map`: actual AprilTag pose in the map frame;
- `approach_pose`: safe free-space robot navigation target;
- `confirmation_pose`: optional robot pose/orientation for viewing the tag.

Navigation must use the approved approach pose.

## Lifecycle

Candidate states:

- unknown
- pending review
- approved
- rejected

Location states:

- unknown
- approved
- retired

Only approved and enabled records may resolve for navigation.

## Storage policy

SQLite will become the authoritative runtime store in LOC-2.

YAML under `config/` is for schema policy and empty seed/import data.
Installed package YAML must not be modified as a runtime database.

## Current phase

LOC-0 provides:

- valid C++17 `ament_cmake` package structure;
- package ownership contract;
- stable service and topic names;
- lifecycle and semantic-type enums;
- schema-versioned empty seed data;
- static and C++ unit tests.

LOC-0 intentionally does not provide:

- a ROS node;
- SQLite persistence;
- candidate approval;
- alias normalization;
- location resolution;
- mapping integration;
- navigation integration;
- AprilTag runtime integration.

Those capabilities are introduced in later phases.
