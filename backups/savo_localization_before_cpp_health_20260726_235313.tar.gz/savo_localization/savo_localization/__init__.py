"""Robot Savo localization ownership package."""

try:
    from .version import __version__
except ImportError:
    __version__ = "0.1.0"

__all__ = ["__version__"]
