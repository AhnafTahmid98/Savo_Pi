#ifndef SAVO_LOCATIONS__SQLITE_REPOSITORY_HPP_
#define SAVO_LOCATIONS__SQLITE_REPOSITORY_HPP_

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

#include "savo_locations/model.hpp"
#include "savo_locations/sqlite_store.hpp"
#include "savo_locations/validation.hpp"

namespace savo_locations
{

enum class SnapshotCode : std::uint8_t
{
  kOk = 0U,
  kInvalidArgument,
  kStoreNotOpen,
  kValidationFailed,
  kIdentityConflict,
  kTagConflict,
  kTransactionActive,
  kSqlError,
  kCorruptData,
};


struct SnapshotResult
{
  bool success{false};

  SnapshotCode code{
    SnapshotCode::kSqlError};

  int sqlite_code{0};
  std::string reason;

  std::vector<ValidationIssue>
    validation_issues;
};


struct CatalogSnapshot
{
  std::vector<LocationRecordData> locations;
  std::vector<CandidateRecordData> candidates;
};


[[nodiscard]]
std::string_view to_string(
  SnapshotCode code) noexcept;


class SqliteRepository
{
public:
  explicit SqliteRepository(
    SqliteStore & store);

  [[nodiscard]]
  SnapshotResult save_snapshot(
    const CatalogSnapshot & snapshot);

  [[nodiscard]]
  SnapshotResult load_snapshot(
    CatalogSnapshot * snapshot) const;

private:
  SqliteStore & store_;
};

}  // namespace savo_locations

#endif  // SAVO_LOCATIONS__SQLITE_REPOSITORY_HPP_
