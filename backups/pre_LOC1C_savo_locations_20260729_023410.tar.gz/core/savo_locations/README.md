# Robot Savo — `savo_locations`

`savo_locations` is the authoritative semantic-location registry for
Robot Savo.

## Ownership

This package owns:

- canonical location IDs;
- human-readable display names;
- deterministic aliases;
- semantic location types;
- active-map and map-revision binding;
- released-map provenance;
- safe navigation approach poses;
- optional confirmation poses;
- expected AprilTag family and ID;
- candidate and approved-location lifecycle;
- location enable/disable state;
- registry persistence and audit history.

This package does not own:

- AprilTag image detection;
- camera-to-map transformations;
- occupancy-grid validation;
- path planning;
- motor commands;
- natural-language intent classification;
- final robot-wide safety authorization.

## Package relationships

- `savo_head` visually detects and confirms AprilTags.
- `savo_mapping` georeferences observations and proposes candidates.
- `savo_locations` stores and resolves approved locations.
- `savo_nav` consumes a resolved approach pose and confirms arrival.
- SavoMind or `savo_bridge` resolves natural-language destination intent.
- `savo_supervisor` observes readiness and safety state.

## Locked LOC-0 terminology

Map context uses:

- `map_id`
- `map_revision`
- `map_release_id`

`map_revision` is the active numeric map revision used by runtime
contracts.

`map_release_id` records released-map provenance and is not a substitute
for `map_revision`.

## Pose separation

The AprilTag pose is not automatically a safe navigation goal.

A location may contain:

- `tag_pose_map`: actual AprilTag pose in the map frame;
- `approach_pose`: safe free-space robot navigation target;
- `confirmation_pose`: optional robot pose/orientation for viewing the tag.

Navigation must use the approved approach pose.

## Lifecycle

Candidate states:

- unknown
- pending review
- approved
- rejected

Location states:

- unknown
- approved
- retired

Only approved and enabled records may resolve for navigation.

## Storage policy

SQLite will become the authoritative runtime store in LOC-2.

YAML under `config/` is for schema policy and empty seed/import data.
Installed package YAML must not be modified as a runtime database.

## Current phase

LOC-0 provides:

- valid C++17 `ament_cmake` package structure;
- package ownership contract;
- stable service and topic names;
- lifecycle and semantic-type enums;
- schema-versioned empty seed data;
- static and C++ unit tests.

LOC-0 intentionally does not provide:

- a ROS node;
- SQLite persistence;
- candidate approval;
- alias normalization;
- location resolution;
- mapping integration;
- navigation integration;
- AprilTag runtime integration.

Those capabilities are introduced in later phases.
## LOC-1A normalization and validation

LOC-1A adds a ROS-independent deterministic C++ domain core.

It provides:

- ASCII whitespace trimming and collapsing;
- deterministic lookup-key normalization;
- canonical location-ID conversion and validation;
- pure C++ map, pose, tag, location and candidate models;
- finite numeric-value validation;
- mandatory `map` frame validation;
- normalized quaternion validation;
- alias collision detection;
- semantic-type validation;
- map-revision and AprilTag validation;
- stable machine-readable validation reason codes.

LOC-1A does not introduce a database, ROS node, service server,
launch file, mapping integration or navigation integration.

Lookup normalization performs ASCII case conversion only.
Non-ASCII UTF-8 bytes are preserved exactly so behavior does not
depend on the operating-system locale. Full Unicode case folding
may be added later through an explicitly selected dependency.
## LOC-1B in-memory registry

LOC-1B adds a deterministic, thread-safe, ROS-independent
in-memory location registry.

The registry supports:

- canonical location-ID insertion;
- globally unique location IDs;
- identity collision protection within a map revision;
- AprilTag collision protection within a map revision;
- exact ID, display-name and alias resolution;
- optional map-context enforcement;
- explicit ambiguous, disabled, retired and map-mismatch results;
- optimistic record revision checks;
- strict revision increment sequencing;
- revisioned enable/disable changes;
- deterministic location-ID-sorted listing.

A disabled location continues to reserve its identity and tag.
A retired location releases its identity and tag for future use.

A matching identity across different maps is allowed. Resolution
without map context must return ambiguous rather than selecting
one destination silently.

LOC-1B still does not add SQLite, a ROS node, ROS services,
launch files, mapping integration or navigation integration.
