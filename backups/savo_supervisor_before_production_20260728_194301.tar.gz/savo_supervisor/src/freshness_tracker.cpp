// Copyright 2026 Ahnaf Tahmid
// SPDX-License-Identifier: LicenseRef-Proprietary

#include "savo_supervisor/freshness_tracker.hpp"

#include <cmath>

namespace savo_supervisor
{

void FreshnessTracker::mark_disabled()
{
  disabled_ = true;
}

void FreshnessTracker::observe_message(
  const rclcpp::Time & receive_time,
  const std::optional<builtin_interfaces::msg::Time> & header_stamp,
  bool malformed,
  const std::string & detail)
{
  if (disabled_) {
    return;
  }

  const bool was_received = received_;
  received_ = true;

  if (malformed) {
    malformed_ = true;
    malformed_count_ += 1;
    detail_ = detail;
    timestamp_fault_ = false;
  } else {
    malformed_ = false;
    detail_.clear();
    if (header_stamp.has_value()) {
      const auto & stamp = header_stamp.value();
      const int64_t stamp_ns = stamp.sec * 1000000000LL + stamp.nanosec;
      if (last_header_stamp_ns_ >= 0 && stamp_ns < last_header_stamp_ns_) {
        timestamp_fault_ = true;
        detail_ = "timestamp regression";
      } else {
        if (timestamp_fault_) {
          recovery_count_ += 1;
        }
        timestamp_fault_ = false;
      }
      last_header_stamp_ns_ = stamp_ns;
    }
  }

  last_receive_time_ = receive_time;
  if (!was_received && !malformed_) {
    recovery_count_ += 1;
  }
}

FreshnessSnapshot FreshnessTracker::snapshot(
  const rclcpp::Time & now,
  double timeout_s) const
{
  FreshnessSnapshot snapshot;
  snapshot.disabled = disabled_;
  snapshot.valid = !disabled_;
  snapshot.timeout_s = timeout_s;

  if (disabled_) {
    snapshot.valid = false;
    snapshot.detail = "disabled";
    return snapshot;
  }

  snapshot.received = received_;
  snapshot.malformed = malformed_;
  snapshot.malformed_count = malformed_count_;
  snapshot.recovery_count = recovery_count_;
  snapshot.last_receive_time = last_receive_time_;

  if (!received_) {
    snapshot.stale = true;
    snapshot.detail = "never received";
    snapshot.age_s = std::numeric_limits<double>::infinity();
    return snapshot;
  }

  const auto delta = now - last_receive_time_;
  snapshot.age_s = delta.seconds();
  snapshot.stale = snapshot.age_s > timeout_s;

  if (malformed_) {
    snapshot.valid = false;
    snapshot.detail = detail_.empty() ? "malformed payload" : detail_;
  } else if (timestamp_fault_) {
    snapshot.valid = false;
    snapshot.detail = "timestamp fault";
  } else if (snapshot.stale) {
    snapshot.valid = false;
    snapshot.detail = "message stale";
  } else {
    snapshot.valid = true;
    snapshot.detail = "fresh";
  }

  return snapshot;
}

bool FreshnessTracker::received() const
{
  return received_;
}

std::size_t FreshnessTracker::malformed_count() const
{
  return malformed_count_;
}

std::size_t FreshnessTracker::recovery_count() const
{
  return recovery_count_;
}

} // namespace savo_supervisor
