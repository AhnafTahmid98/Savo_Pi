#include <gtest/gtest.h>
#include "savo_supervisor/freshness_tracker.hpp"
#include "rclcpp/rclcpp.hpp"

using namespace savo_supervisor;

TEST(FreshnessTracker, DisabledSnapshot)
{
  FreshnessTracker tracker;
  tracker.mark_disabled();

  rclcpp::Clock clock(RCL_ROS_TIME);
  const auto now = clock.now();
  const auto snapshot = tracker.snapshot(now, 1.0);

  EXPECT_TRUE(snapshot.disabled);
  EXPECT_FALSE(snapshot.valid);
  EXPECT_FALSE(snapshot.received);
}

TEST(FreshnessTracker, ObserveMessage)
{
  FreshnessTracker tracker;
  rclcpp::Clock clock(RCL_ROS_TIME);
  const auto now = clock.now();

  builtin_interfaces::msg::Time stamp;
  stamp.sec = static_cast<int32_t>(now.seconds());
  stamp.nanosec = 0u;

  tracker.observe_message(now, stamp, false, "");
  const auto snapshot = tracker.snapshot(now, 1.0);

  EXPECT_TRUE(snapshot.received);
  EXPECT_FALSE(snapshot.stale);
  EXPECT_EQ(snapshot.timeout_s, 1.0);
}
